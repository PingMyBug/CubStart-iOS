//
//  Shopping_ListApp.swift
//  Shopping List
//
//  Created by Tony Hong on 3/11/22.
//

import SwiftUI

@main
struct Shopping_ListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
